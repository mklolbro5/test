# Security Policy

## Supported Versions
This is a demo repository. There is no production code.

## Responsible Disclosure
If you discover a security issue related to this repository or its documentation,
please disclose responsibly and avoid including harmful payloads. Provide only
minimal, safe proofs-of-concept and focus on remediation steps.
